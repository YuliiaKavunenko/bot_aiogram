import sqlite3

def create_db():
    connect = sqlite3.connect("database.db")
    cursor = connect.cursor()
    

    cursor.execute("CREATE TABLE IF NOT EXISTS Admins(email TEXT, nickname TEXT, password TEXT, phone_number TEXT)")
    connect.commit()
    connect.close()


def create_cart():
    connect = sqlite3.connect("data_cart.db")
    cursor = connect.cursor()


    cursor.execute("CREATE TABLE IF NOT EXISTS Cart(name TEXT, amount TEXT, id TEXT, phone_number TEXT, email TEXT)")
    connect.commit()
    connect.close()

create_db()
create_cart()