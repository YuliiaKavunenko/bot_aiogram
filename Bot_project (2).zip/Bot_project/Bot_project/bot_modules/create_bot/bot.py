import aiogram

bot = aiogram.Bot(token = "6475957700:AAH1wxcD9lS7DPBQFiG5WjNlsd4xq7aspWk")
# a = await bot.