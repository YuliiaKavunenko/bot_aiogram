import aiogram 
import bot_modules.create_buttons.keyboard_buttons as kb_buttons

keyboard = aiogram.types.ReplyKeyboardMarkup(
    keyboard = [[kb_buttons.button_admin, kb_buttons.button_klient]]
)
inline_keyboard = aiogram.types.InlineKeyboardMarkup(inline_keyboard=[[kb_buttons.button_select, kb_buttons.button_info], [kb_buttons.button_confirmation]])

new_keyboard = aiogram.types.ReplyKeyboardMarkup(
    keyboard = [[kb_buttons.button_avt, kb_buttons.button_reg]]
) 

clear_keyboard = aiogram.types.ReplyKeyboardRemove()
moderator_keyboard = aiogram.types.InlineKeyboardMarkup(
    inline_keyboard = [[kb_buttons.button_confirm]]
)