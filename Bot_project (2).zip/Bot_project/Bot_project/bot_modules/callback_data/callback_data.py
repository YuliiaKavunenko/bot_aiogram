import sqlite3
import aiogram
import bot_modules.create_dispatcher.dispatcher as dispatcher    
import bot_modules.create_buttons.keyboard_buttons as m_buttons  
import bot_modules.create_keyboard.keyboard as our_keyboard      
import bot_modules.create_table.create_table as m_table          
import bot_modules.message_handler.message_handler as m_handler 
import bot_modules.create_bot.bot as m_bot
import bot_modules.create_message.create_message as m_message

count_dict = {
    "count": 0
}

@dispatcher.dispatcher.callback_query()
async def callback(callback: aiogram.types.CallbackQuery):
    if callback.data == "accept":
        # print("callback2")
        con = sqlite3.connect("database.db")
        cursor = con.cursor()
        cursor.execute("INSERT INTO Admins (email, nickname, password, phone_number) VALUES (?,?,?,?)", (m_handler.data['email'], m_handler.data['nickname'], m_handler.data['password'], m_handler.data['phone_number']))
        con.commit()
        await m_bot.bot.send_message(m_handler.user_id, "Успішно підтверджено")
        await m_bot.bot.send_message(chat_id = callback.from_user.id, text = "Успішно підтверджено")
        # print(f'{callback.from_user.id}')
        # print(f'{m_handler.user_id}')
        # else: 
        #     print('error')
        print(m_handler.user_id)
    if callback.data == "info":
        # global product_name
        product_name = m_handler.product_name
        await m_bot.bot.send_message(m_handler.user_id, f"{m_message.products[product_name]['info']}") #
    if callback.data == "select":
        count_dict["count"] += 1
        our_keyboard.inline_keyboard.inline_keyboard[0][0].text = f"Обрати {count_dict["count"]}"
        await callback.message.edit_reply_markup(inline_message_id = callback.inline_message_id, reply_markup = our_keyboard.inline_keyboard)
    if callback.data == "confirm":
        product_name = m_handler.product_name
        con_cart = sqlite3.connect("data_cart.db")
        cursor_cart = con_cart.cursor()
        cursor_cart.execute("INSERT INTO Cart (name , amount, id, phone_number, email) VALUES(?, ?, ?, ?, ?)", (m_message.products[product_name]['name'], count_dict["count"], m_handler.user_id, str(m_handler.data["phone_number"]), m_handler.data["email"]))
        con_cart.commit()
        await m_bot.bot.send_message(m_handler.user_id, f"Товар {m_message.products[product_name]['name']} успішно додано")
