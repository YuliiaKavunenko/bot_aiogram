import aiogram 
import bot_modules.create_bot.bot as bot 
import bot_modules.create_dispatcher.dispatcher as dp 
import bot_modules.create_keyboard.keyboard as kb
import aiogram.filters as ft
# import bot_modules.message_handler.message_handler as m_handle

products = {}#дані про продукт, який додається
state = {}#стан при виконанні команди add_message


print('start')
@dp.dispatcher.message(ft.Command('add_message'))
async def command_add_message(message: aiogram.types.Message):

    user_id = message.from_user.id
    print('create message')
    await message.answer(text = 'Надішліть назву продукту 😀')
    state[user_id] = 'name'






        

        
    






















