import aiogram

dispatcher = aiogram.Dispatcher()